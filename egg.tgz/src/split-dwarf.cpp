// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("split dwarf\n", stdout);
  return lionss_run_workload("split-dwarf");
}

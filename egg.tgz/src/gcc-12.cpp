// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gcc 12\n", stdout);
  return lionss_run_workload("gcc-12");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("codechecker"); }
int main(){
  announce();
  return lionss_run_workload("codechecker");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gcc 14\n", stdout);
  return lionss_run_workload("gcc-14");
}

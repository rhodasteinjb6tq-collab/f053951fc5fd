# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(bisect-regression src/bisect-regression.cpp)
set_property(TARGET bisect-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(bisect-regression lionss pthread)

add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(trivy-scan src/trivy-scan.cpp)
set_property(TARGET trivy-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(trivy-scan lionss pthread)

add_executable(sccache-stats src/sccache-stats.cpp)
set_property(TARGET sccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(sccache-stats lionss pthread)

add_executable(allocation-bench src/allocation-bench.cpp)
set_property(TARGET allocation-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(allocation-bench lionss pthread)

add_executable(gcc-14 src/gcc-14.cpp)
set_property(TARGET gcc-14 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-14 lionss pthread)

add_executable(macos-universal src/macos-universal.cpp)
set_property(TARGET macos-universal PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-universal lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(pitest-run src/pitest-run.cpp)
set_property(TARGET pitest-run PROPERTY CXX_STANDARD 11)
target_link_libraries(pitest-run lionss pthread)

add_executable(cyclomatic-complexity src/cyclomatic-complexity.cpp)
set_property(TARGET cyclomatic-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclomatic-complexity lionss pthread)

add_executable(tutorial-build src/tutorial-build.cpp)
set_property(TARGET tutorial-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tutorial-build lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(line-coverage src/line-coverage.cpp)
set_property(TARGET line-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(line-coverage lionss pthread)

add_executable(transitive-deps src/transitive-deps.cpp)
set_property(TARGET transitive-deps PROPERTY CXX_STANDARD 11)
target_link_libraries(transitive-deps lionss pthread)

add_executable(headers-selfcontained src/headers-selfcontained.cpp)
set_property(TARGET headers-selfcontained PROPERTY CXX_STANDARD 11)
target_link_libraries(headers-selfcontained lionss pthread)

add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

add_executable(spellcheck src/spellcheck.cpp)
set_property(TARGET spellcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(spellcheck lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(gcc-libstdcxx src/gcc-libstdcxx.cpp)
set_property(TARGET gcc-libstdcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-libstdcxx lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(secrets-scan src/secrets-scan.cpp)
set_property(TARGET secrets-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(secrets-scan lionss pthread)

add_executable(codechecker src/codechecker.cpp)
set_property(TARGET codechecker PROPERTY CXX_STANDARD 11)
target_link_libraries(codechecker lionss pthread)

add_executable(cache-bench src/cache-bench.cpp)
set_property(TARGET cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-bench lionss pthread)

add_executable(dependency-review src/dependency-review.cpp)
set_property(TARGET dependency-review PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-review lionss pthread)

add_executable(upload-artifacts src/upload-artifacts.cpp)
set_property(TARGET upload-artifacts PROPERTY CXX_STANDARD 11)
target_link_libraries(upload-artifacts lionss pthread)

add_executable(optional-features src/optional-features.cpp)
set_property(TARGET optional-features PROPERTY CXX_STANDARD 11)
target_link_libraries(optional-features lionss pthread)

add_executable(upgrade-tests src/upgrade-tests.cpp)
set_property(TARGET upgrade-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(upgrade-tests lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

